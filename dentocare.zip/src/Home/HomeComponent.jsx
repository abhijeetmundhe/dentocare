import React from "react";
import AppointmentComponent from "../Appointment/AppointmentComponent";
import SearchAutoCompleteComponent from "./SearchAutoCompleteComponent";

class HomeComponent extends React.Component {

    render() {
        const data = require('../Data/PatientData.json');
        // const firstObj = { name: 'Abhijeet', age: 33 };
        // const firstObjStr = JSON.stringify(firstObj);
        // localStorage.setItem('firstObj', firstObjStr);

        const firstObjFromStorage = localStorage.getItem('firstObj');
        console.log('*** firstObjFromStorage = ' + JSON.parse(firstObjFromStorage).name);
        return (<div className='Home-component'>
            <AppointmentComponent coreData={data}/>
            <div className='Home-right-section'>
                <button className='Add-pat-btn'> Add New Patient </button>
                <SearchAutoCompleteComponent patData={data.map(patient => patient.Name)}/>
                <button className='Open-pat-btn'> Open </button>
            </div>
        </div>);
    }
}
export default HomeComponent;