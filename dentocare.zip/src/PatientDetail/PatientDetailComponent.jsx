import React from "react";

class PatientDetailComponent extends React.Component {

    constructor(props) {
        super(props);
    }
    render() {
        return (<div> Patient Detail COMPONENT </div>);
    }
}
export default PatientDetailComponent;