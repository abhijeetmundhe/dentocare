import React from 'react';
import './App.css';
import HomeComponent from "./Home/HomeComponent";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>
          Welcome to DENTOCARE App
        </p>
        <HomeComponent/>
      </header>
    </div>
  );
}

export default App;
